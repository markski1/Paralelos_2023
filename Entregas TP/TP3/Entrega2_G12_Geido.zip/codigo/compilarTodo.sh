mpicc mpi.c -o mpi -O2
mpicc openmp-mpi.c -o omp-mpi -fopenmp -O2